const Discord = require("discord.js");
const bot = new Discord.Client({disableEveryone: true});
const settings = require('./settings.json');
const chalk = require('chalk');
const fs = require('fs');
const DBL = require(`dblapi.js`);
const dbl = new DBL('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY4NDgwNTIyNDU3MzA0MjY4OCIsImJvdCI6dHJ1ZSwiaWF0IjoxNTg4ODQxNjQxfQ.ha6lwIKlLKUk7I-scFNth6PRLNua9cTuu0fwJxoYIXY', { webhookPort: 3000, webhookAuth: 'Witch' })
const moment = require('moment');
require('./util/eventLoader')(bot);

//loading messages
const log = message => {
  console.log(`[${moment().format('YYYY-MM-DD HH:mm:ss')}] ${message}`);
};

bot.on("ready", () => {
    bot.user.setActivity(`witch-bot.xyz | wi-help`, { type: "WATCHING"})
})

bot.on('ready', () => {
    console.log(`Now i am ready`)})
dbl.webhook.on('ready', hook => {
    console.log(`Webhook running on http://dblwebhook4.glitch.me/dblhook`);});
dbl.webhook.on('vote', async vote => {
let user = await bot.fetchUser(vote.user)
  bot.guilds.get("705836372199604274").channelsGet("707921045893677127").send(user.tag+" voted Witch");
});

bot.on("guildCreate", function(guild){
  bot.guilds.get(`705836372199604274`).channels.get(`707676812682985532`).send(`Witch has joined a server: **${guild.name}** ID: **${guild.id}** Total: **${guild.memberCount}** `)
  })
bot.on("guildDelete", function(guild){
bot.guilds.get(`705836372199604274`).channels.get(`707676812682985532`).send(`Witch has left a server: **${guild.name}** ID: **${guild.id}**`)

});

bot.commands = new Discord.Collection();
bot.aliases = new Discord.Collection();
fs.readdir('./commands/', (err, files) => {
  if (err) console.error(err);
  files.forEach(f => {
    let props = require(`./commands/${f}`);
    bot.commands.set(props.help.name, props);
    props.conf.aliases.forEach(alias => {
      bot.aliases.set(alias, props.help.name);
    });
  });
});

bot.on('message', message=> {
    if (message.isMentioned(bot.user)) {
  message.channel.send({embed: { color: 10181046, description: `<a:welcome:705811325884039219> | Hi, I'm **${bot.user.username}**, I saw I was pinged, down you have some info :)\n\n__Informations__:\n<a:flower:705812862551064626> **${bot.user.username}** has prefix: **w!**\n<a:flower:705812862551064626> Use command **wi-help** to see the commands\n\<a:flower:705812862551064626> My owner is: **kiosk#0001**`}}).then(msg => {
    msg.delete(5000)})
}
});

bot.on("guildCreate", guild => {
  let channelID;
  let channels = guild.channels;
  channelLoop:
  for (let c of channels) {
      let channelType = c[1].type;
      if (channelType === "text") {
          channelID = c[0];
          break channelLoop;
      }
  }

  let channel = bot.channels.get(guild.systemChannelID || channelID);
  channel.send({embed: { color: 10181046, description: `Hi I'm a Witch :eyes:! A bot made by **kiosk#0001** - Thanks for inviting me into this server! Please do wi-help for the informations you WILL need in order for the bot to work properly <a:checkmark:705719883094294568>`}}).then(message => {msg.delete(1000)});

  let blacklist = JSON.parse(fs.readFileSync("./blacklist.json", "utf8"));
    bot.guilds.forEach((guild) => {
      if (!blacklist[guild.ownerID]) return
      if(blacklist[guild.ownerID].state === true) {
        channel.send("But **__UNFORTUNATELY__**, the owner of this server has been blacklisted before so I'm LEAVING! Bye!")
        guild.leave(guild.id)
      }
    })
});
//command reload
bot.reload = command => {
  return new Promise((resolve, reject) => {
    try {
      delete require.cache[require.resolve(`./commands/${command}`)];
      let cmd = require(`./commands/${command}`);
      bot.commands.delete(command);
      bot.aliases.forEach((cmd, alias) => {
        if (cmd === command) bot.aliases.delete(alias);
      });
      bot.commands.set(command, cmd);
      cmd.conf.aliases.forEach(alias => {
        bot.aliases.set(alias, cmd.help.name);
      });
      resolve();
    } catch (e){
      reject(e);
    }
  });
};

bot.elevation = message => {
	if (message.channel.type === 'dm') return;
	let permlvl = 0;
	let mod_role = message.guild.roles.find(x => x.name === settings.modrolename);
	if (mod_role && message.member.roles.has(mod_role.id)) permlvl = 1;
	let admin_role = message.guild.roles.find(x => x.name === settings.adminrolename);
	if (admin_role && message.member.roles.has(admin_role.id)) permlvl = 2;
	let manager_role = message.guild.roles.find(x => x.name === settings.managerrolename);
	if (manager_role && message.member.roles.has(manager_role.id)) permlvl = 3;
	let overlord_role = message.guild.roles.find(x => x.name === settings.overlordrolename)
	if (overlord_role && message.member.roles.has(overlord_role.id)) permlvl = 4;
	if (message.author.id === settings.ownerid) permlvl = 5;
	return permlvl;
};

//ping log 
//var regToken = /[\w\d]{24}\.[\w\d]{6}\.[\w\d-_]{27}/g;
//bot.on('debug', e => {
//  console.log(e.replace(regToken, 'that was redacted'));
//});


bot.login(settings.token);
