const fights = require('../data/fights.json');
exports.run = (bot, message, args) => {
  let user = message.mentions.users.first();
  let reason = args.slice(0).join(' ');
  if (reason.length < 1) return message.reply('**MAGIC**! You can\'t use spell on air. Mention someone. :sparkles:');
  if(message.mentions.users.first().id === "482128001828651008") return message.reply('Kame KAme KAME HAAAAAA. ***It dealt ∞ damage. You got demolished.*** Witch won');
  if(message.mentions.users.first().id === "228055182821425152") return message.reply('You can\'t fight with him.  He have a more powerful spell :broom:');
      message.channel.send(`${message.author.username} is fighting ${message.mentions.users.first().username} ${fights[Math.floor(Math.random() * fights.length)]}`)
  }


exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: 'fight',
  description: 'Fights a user.',
  usage: 'fight <user>'
};
