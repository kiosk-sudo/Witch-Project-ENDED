exports.run = (bot, message, args) => {
  if (!bot.lockit) bot.lockit = [];
  if (!message.member.hasPermission("MANAGE_CHANNELS")) return message.reply({embed: { title: ":sparkles: **Woosh! I think the spell got broken..**", description: "You don't have the permission to do that!", timestamp: message.createdAt}});

  message.channel.overwritePermissions(message.guild.id, {
      SEND_MESSAGES: false
    })
      message.channel.send({embed: { title: "**Please have patience...**", description: `Damnn, **${message.author.username}** just enchanted channel with a spell. Don't worry, Admins will soon open the chat again so be patient. :broom:`, timestamp: message.createdAt}});
  };
  
exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['ld'],
  permLevel: 0
};

exports.help = {
  name: 'lockdown',
  description: 'This will lock a channel down.',
  usage: 'lockdown'
};
