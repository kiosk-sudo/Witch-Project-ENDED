const ms = require('ms');
exports.run = (bot, message, args) => {
  if (!bot.lockit) bot.lockit = [];
  let time = args.join(' ');
  let validUnlocks = ['release', 'unlock'];
  if (!message.member.hasPermission("MANAGE_CHANNELS")) return msg.reply({embed: { title: ":no_entry_sign: **Error**", description: "You don't have the permission to do that!", timestamp: message.createdAt}});
  if (!time) return message.reply({embed: { title: "**Specify..**", description: 'You must set a duration for the lockdown in either hours, minutes or seconds', timestamp: message.createdAt}});

  if (validUnlocks.includes(time)) {
    message.channel.overwritePermissions(message.guild.id, {
      SEND_MESSAGES: null
    }).then(() => {
      message.channel.send({embed: { title: "**Lockdown lifted**", description: "Talk while you can ;)", timestamp: message.createdAt}});
      clearTimeout(bot.lockit[message.channel.id]);
      delete bot.lockit[message.channel.id];
    }).catch(error => {
      console.log(error);
    });
  } else {
    message.channel.overwritePermissions(message.guild.id, {
      SEND_MESSAGES: false
    }).then(() => {
      message.channel.send({embed: { title: "**Please have patience...**", description: `Damnn, **${message.author.username}** just locked the channel down for ${ms(ms(time), { long:true })}`, timestamp: message.createdAt}}).then(() => {

        bot.lockit[message.channel.id] = setTimeout(() => {
          message.channel.overwritePermissions(message.guild.id, {
            SEND_MESSAGES: null
          }).then(message.channel.send({embed: { title: "**Lockdown lifted**", description: "Talk while you can ;)", timestamp: message.createdAt}})).catch(console.error);
          delete bot.lockit[message.channel.id];
        }, ms(time));

      }).catch(error => {
        console.log(error);
      });
    });
  }
};
exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['tld'],
  permLevel: 0
};

exports.help = {
  name: 'timedlockdown',
  description: 'This will lock a channel down for the set duration, be it in hours, minutes or seconds.',
  usage: 'timedlockdown <duration>'
};
