const Discord =  require('discord.js');
const customisation = require('../customisation.json');
exports.run = (bot, message, args) => {
    let avatar = message.mentions.users.size ? message.mentions.users.first().avatarURL : message.author.avatarURL;
    if (message.mentions.users.size > 0) {
      const embed = new Discord.RichEmbed()
        .setColor("#ad91ff")
        .setTitle(`${message.mentions.users.first().username}'s **MAGIC AVATAR**`)
        .setImage(`${avatar + "?size=512"}`)
        .setFooter(`© Witch Bot by ${customisation.ownername}`);
        message.channel.send({embed});
    } else {
      const embed = new Discord.RichEmbed()
      .setColor("#ad91ff")
      .setTitle(`${message.author.username}'s **AVATAR**`)
      .setImage(`${avatar + "?size=512"}`)
      .setFooter(`© Witch Bot by ${customisation.ownername}`);
      message.channel.send({embed});
    }
}

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: 'avatar',
  description: 'Fetches a user\'s avatar.',
  usage: 'avatar <user>'
};
