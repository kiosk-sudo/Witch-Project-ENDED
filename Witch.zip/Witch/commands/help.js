const Discord = require('discord.js')
const help = require('../data/helpMsgs.json');
const customisation = require('../customisation.json');
const settings = require('../settings.json');
const fs = require('fs')

module.exports.run = (bot, message, args) => {
 let sicon = message.guild.iconURL;
 const embed = new Discord.RichEmbed()
 .setAuthor(`Witch | Help`, bot.user.displayAvatarURL)
 .setThumbnail(bot.user.displayAvatarURL)
 .addField("<:WitchDD2:706073905101537292> **UTILITY**", "``contact`` ``roleinfo``, ``botvote``, ``avatar``, ``ping``, ``serverinfo``, ``uptime``, ``userinfo``, ``vote``, ``timer``")
 .addField("<:WitchDD2:706073905101537292> **MODERATION**", "``ban``, ``kick``, ``mute``, ``tempmute``, ``warn``, ``hackwarn``, ``clearwarns``, ``warnlevel``, ``lockdown``, ``timedlockdown``, ``unlockdown``, ``addrole``, ``removerole``, ``votekick``, ``rename``")
 .addField("<:WitchDD2:706073905101537292> **FUN**", "``redpanda``, ``panda``, ``truth``, ``dadjoke``, ``copypasta``, ``roll``, ``rps``, ``8ball``, ``wallpaper``, ``cngif``, ``kitsune``, ``neko``, ``cat``, ``dog``, ``shibe``, ``nep``, ``hug``, ``pat``, ``feed``, ``slap``")
 .setColor("#ad91ff")
 .setFooter(`Witch Bot | Requested by ${message.author.tag}`, message.author.displayAvatarURL)
 .setTimestamp()
 message.author.send(embed)
 if (message.content === 'wi-help') {
	message.react('708963293674602558');
}
}

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['h', 'halp'],
  permLevel: 0
};

exports.help = {
  name: 'help',
  description: 'Displays all the available commands for your permission level.',
  usage: 'help [command]'
};

