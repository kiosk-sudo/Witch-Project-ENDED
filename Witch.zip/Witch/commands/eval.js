const Discord = require("discord.js");
const bot = new Discord.Client();
const db = require("quick.db")
 
exports.run = async (bot, message, args) => {
        if (message.author.id !== "228055182821425152" && message.author.id !== "") return message.channel.send("My spell didn't worked because you don't have permission! :sparkles:")
    try {
      const user = message.mentions.users.first() || message.author
      //var dev = "(<:developer:706241960469463043>) Developer"
      var dev = "(<:developer:708353404681846857>) Developer"
     // var vip = "(⭐) VIP"
      var friend = "(<a:WitchWS5:713856926534074449>) Exclusive"
      let reps = db.fetch(`rep_${user.id}`)
      var code = args.join(" ");
      if(!code) return;;
      if (code === "bot.token") return message.channel.send("Token is unavaliable.");
      var evaled = eval(code);

      if (typeof evaled !== "string")
        evaled = require("util").inspect(evaled);
      
      const embed = new Discord.RichEmbed()
       .setColor("#ad91ff")
        .addField(":inbox_tray: Input: ", `\`\`\`${code}\`\`\``)
        .addField(":outbox_tray: Output: ", `\`\`\`js\n${clean(evaled)}\n\`\`\``)
      message.channel.send({embed})
    } catch (err) {
      const embed = new Discord.RichEmbed()
      .setColor("#ad91ff")
      .addField(":inbox_tray: Input: ", `\`\`\`${code}\`\`\``)
      .addField(":outbox_tray: Output: ", `\`\`\`${clean(err)}\`\`\``)
    message.channel.send({embed})
    }

function clean(text) {
  if (typeof(text) === 'string')
    return text.replace(/`/g, '`' + String.fromCharCode(8203)).replace(/@/g, '@' + String.fromCharCode(8203));
  else
      return text;
  }
}

module.exports.help = {
  name: "eval"
}

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['eval'],
  permLevel: 0
};

exports.help = {
  name: 'eval',
  description: 'eval',
  usage: 'eval'
};
