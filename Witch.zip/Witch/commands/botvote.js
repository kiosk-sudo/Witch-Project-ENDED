const Discord = require('discord.js');
const customisation = require('../customisation.json');

exports.run =  (bot, message, args) => {
  message.delete();
  let embed = new Discord.RichEmbed()
    .setTitle("Vote for Witch!")
    .addField("Voting on top.gg:", "https://top.gg/bot/684805224573042688")
    .addField("Voting on discord.boats:", "https://discord.boats/bot/684805224573042688")
    .setFooter(`© Witch Bot by ${customisation.ownername}`);
  message.channel.send({embed});
}
exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: ["bv"],
    permLevel: 0
  };
  
  exports.help = {
    name: 'botvote',
    description: 'Vote us!',
    usage: 'botvote'
  }
  //https://discordbots.org/bot/482128001828651008
