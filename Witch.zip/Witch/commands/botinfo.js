const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
    let inline = true
    let bicon = bot.user.displayAvatarURL;
    let usersize = bot.users.size
    let chansize = bot.channels.size
    let uptimxd = bot.uptime 
    let servsize = bot.guilds.size
    let botembed = new Discord.RichEmbed()
    .setColor("#ad91ff")
    .setThumbnail(bicon)
    .addField("<a:flower:705812862551064626> **BOT NAME**", `${bot.user.username}`)
    .addField("<a:flower:705812862551064626> **BOT OWNER**", "<@228055182821425152>")
    .addField("<a:flower:705812862551064626> **SERVERS**", `📥 ${servsize}`)
    .addField("<a:flower:705812862551064626> **CHANNELS**", `📁 ${chansize}`)
    .addField("<a:flower:705812862551064626> **USERS**", `${usersize}`)
    .addField("<a:flower:705812862551064626> **LIBRARY**", "Discord.js")
    .addField("<a:flower:705812862551064626> **CREATED ON**", bot.user.createdAt)
    .setFooter(`Developed by: kiosk#0001`)
    .setTimestamp()
    
    message.channel.send(botembed);

}

module.exports.help = {
  name:"botinfo"
}

  exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: ["botinfo"],
  permLevel: 0
};
exports.help = {
  name: 'botinfo',
  description: 'Show information about bot.',
  usage: 'botinfo'
};
