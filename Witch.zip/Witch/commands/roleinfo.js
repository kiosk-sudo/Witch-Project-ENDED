const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {
    let inline = true

    let role = args.join(` `)
    if(!role) return message.reply("Specify a role!");
    let gRole = message.guild.roles.find(`name`, role);
    if(!gRole) return message.reply("Couldn't find that role.");

    const status = {
        false: "No",
        true: "Yes"
      }

    const embed  = new Discord.RichEmbed()
    .setTitle(`Role Information`, bot.user.displayAvatarURL)
    .setThumbnail(bot.user.displayAvatarURL)
    .setColor("#ad91ff")
    .addField("<a:flower:705812862551064626>  **ID**", gRole.id)
    .addField("<a:flower:705812862551064626>  **Name**", gRole.name)
    .addField("<a:flower:705812862551064626>  **Color**", gRole.hexColor)
    .addField("<a:flower:705812862551064626>  **Position**", gRole.position)
    .addField("<a:flower:705812862551064626>  **Hoisted**", status[gRole.hoist])
    .addField("<a:flower:705812862551064626>  **Mentionable**", status[gRole.mentionable])
    .setFooter(`Witch Bot | Requested by ${message.author.tag}`, message.author.displayAvatar)
    .setTimestamp()
    message.channel.send(embed)
}

module.exports.help = {
  name:"roleinfo"
}

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["roleinfo"],
  permLevel: 0
};

exports.help = {
  name: 'roleinfo',
  description: 'Information about the role.',
  usage: 'roleinfo [role]'
};

