const Discord = require("discord.js");
const bot = new Discord.Client();


exports.run = (bot, message, args) => {
    if (!message.member.hasPermission("MANAGE_ROLES")) return message.channel.send({embed: { title: "**Action Denied**", description: `:no_entry_sign: | **${message.author.username}**, you don't have permission!`, timestamp: message.createdAt}})
   
        var userz = message.guild.members.array();
        const roletogive = args.join(" ")
        
        let subscriberRole = bot.guilds.get(message.guild.id).roles.find(r => r.name == roletogive);
        if (!subscriberRole) return message.channel.send({embed: { title: "**Spell didn't worked because..**", description:  `:sparkles: | **${message.author.username}** invalid role`, timestamp: message.createdAt}});

      
            
                userz.forEach(u => {
                    u.addRole(subscriberRole)
                })
      message.react('708963293674602558');
        
    }

module.exports.help = {
    name:"roleall"
  }  

exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: ["roleall"],
    permLevel: 0
  };
  
exports.help = {
    name: 'roleall',
    description: 'roleall.',
    usage: 'roleall'
  };
