const settings = require('../settings.json');
exports.run = (bot, message, args) => {
  let user = message.mentions.users.first();
  let reason = args.slice(0).join(' ');
  if (reason.length < 1) return message.reply('You can\'t use my throwing hammer spell on air, mention someone!');
  if(message.mentions.users.first().id === "228055182821425152") return message.reply('You can\'t use spell on yourself :sparkles:')
  message.channel.send(`${message.author.username} threw a hammer at ${message.mentions.users.first().username}. :hammer:`)
  }

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: 'hammer',
  description: 'Gives you a hammer to throw at a pleb.',
  usage: 'hammer'
};
