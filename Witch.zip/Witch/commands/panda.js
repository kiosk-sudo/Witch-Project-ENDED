const Discord = require('discord.js');
const superagent = require('superagent');
const sf = require("snekfetch");
const customisation = require('../customisation.json');
const fetch = require("node-fetch");
exports.run = async (bot, message, args) => {
const panda = await fetch("https://some-random-api.ml/img/panda")
      .then(res => res.json())
      .then(json => json.link);

    const embed = new Discord.RichEmbed()
    .setColor("#ad91ff")
    .setTitle("🐼 Here is your panda 🐼")
    .setImage(panda)
    .setFooter(`© Witch Bot by ${customisation.ownername}`);
    message.channel.send({embed});
};

exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: [],
    permLevel: 0
  };

  exports.help = {
    name: 'panda',
    description: 'Sends a random panda',
    usage: 'panda'
  };
