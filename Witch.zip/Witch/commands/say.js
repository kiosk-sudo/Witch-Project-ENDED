exports.run = (bot, message) => {
    let args = message.content.split(" ").slice(1);
    message.delete();
    if (args.join(" ") === "@everyone" || args.join(" ") === "@here") return message.channel.send("The spell don't work on main pings.. :broom:");
    if (!message.member.hasPermission("MANAGE_MESSAGES")) return message.channel.send(":no_entry_sign: **Error:** You don't have the permission to use this command! <a:flower:705812862551064626>");
    message.channel.send(args.join(" "));
};

exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: [],
    permLevel: 0
};

exports.help = {
    name: "say",
    description: "Makes the bot repeat your message.",
    usage: "say [message]"
};
