module.exports = bot => {
  console.log(`Reconnecting at ${new Date()}`);
};
