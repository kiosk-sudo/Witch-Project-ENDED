module.exports = bot => {
  console.log(`You have been disconnected at ${new Date()}`);
};
